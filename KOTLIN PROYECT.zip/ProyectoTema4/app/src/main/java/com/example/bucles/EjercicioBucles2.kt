package com.example.bucles

fun main() {

    println("Tabla de multiplicar del 5 usando bucle while:")
    var i = 1
    while (i <= 10) {
        val resultado = 5 * i
        println("5 * $i = $resultado")
        //println("5"+"*"+i+ " = "+resultado)
        i++
    }

}


